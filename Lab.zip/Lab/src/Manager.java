import java.util.ArrayList;
import java.util.List;

public class Manager extends Employee {

    private List<Employee> employees = new ArrayList<>();

    protected Manager(String firstName, String lastName, double salary) {
        super(firstName, lastName, salary);
    }

    @Override
    public double GetSalary() {
        var result = Salary;

        for (var e : employees) {
            result += e.Salary;
        }

        return result;
    }

    @Override
    public void PrintName() {
        System.out.println(FirstName + " " + LastName);

        for (var e : employees) {
            System.out.println(e.FirstName + " " + e.LastName);
        }
    }

    @Override
    public void AddEmployee(Employee e) {
        employees.add(e);
    }

    @Override
    public void RemoveEmployee(Employee e) {
        employees.remove(e);
        System.out.println("employee deleted");
    }
}

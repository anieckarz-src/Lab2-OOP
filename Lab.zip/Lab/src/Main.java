public class Main {
    public static void main(String[] args) {

        var mainManager = new Manager("adix","niec",10000);
        var worker1 = new Worker("WorkerFirstName1","WorkerLastName1",1000);
        var worker2 = new Worker("WorkerFirstName2","WorkerLastName2",2000);

        mainManager.AddEmployee(worker1);
        mainManager.AddEmployee(worker2);

        System.out.println(mainManager.GetSalary());

        mainManager.PrintName();
        mainManager.RemoveEmployee(worker1);

        mainManager.PrintName();

    }
}
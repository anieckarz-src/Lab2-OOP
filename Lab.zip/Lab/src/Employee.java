public abstract class Employee {

    protected String FirstName;
    protected String LastName;
    protected double Salary;

    protected Employee(String firstName, String lastName, double salary) {
        FirstName = firstName;
        LastName = lastName;
        Salary = salary;
    }

    public abstract double GetSalary();
    public abstract void PrintName();
    public abstract void AddEmployee(Employee e);
    public abstract void RemoveEmployee(Employee e);





}
